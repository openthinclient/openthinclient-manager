/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.autoupdate;

import java.io.File;
import java.io.IOException;
import java.util.*;

import org.openide.util.NbBundle;
import org.openide.util.datatransfer.NewType;

/** Represents add Nbm object in the Option - Modules - New.
 * XXX use Looks in the future
 * @author Ales Kemr
 */
public class AutoModuleNewType extends NewType {
        
    public String getName () {
        return NbBundle.getMessage( AutoModuleNewType.class, "CTL_NewModuleByNBM" );
    }

    public void create () throws IOException {
        addFile ();
    }

    void addFile () throws IOException {
        List files = SelectModulesPanel.selectNbmFiles();
        
        if ( files != null ) {
            File[] allFiles = new File[ files.size() ];
            Iterator it = files.iterator();
            for ( int i = 0; it.hasNext(); i++ ) {
                File fn = (File)it.next();
                if ( fn != null ) {
                    allFiles[i] = fn;                    
                }
            }
            XMLUpdates updates = new XMLUpdates( allFiles );
            HashMap allUpdates = new HashMap();
            allUpdates.put(this, updates);
            Wizard wiz = Wizard.go( allUpdates, 1 );
            if ( wiz != null ) {
                updates.checkDownloadedModules();
                wiz.refreshUpdatePanel();
            }
        }
    }

}
