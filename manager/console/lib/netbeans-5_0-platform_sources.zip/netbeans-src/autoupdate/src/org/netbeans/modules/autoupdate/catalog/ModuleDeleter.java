/*
 *                 Sun Public License Notice
 *
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 *
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2005 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.autoupdate.catalog;

import java.io.IOException;
import org.netbeans.Module;

/** <code>ModuleDeleter</code> deletes module's files from installation if possible.
 * Checks if all information about files are known and deletes file from disk.
 * This interface is implemented in <code>Autoupdate</code> module.
 * 
 * @author Jiri Rechtacek
 */
public interface ModuleDeleter {
    
    /** Are all information about files of the given module known.
     * 
     * @param module 
     * @return true if info is available
     */
    public boolean canDelete (Module module);
    
    /** Deletes all module's file from installation.
     * 
     * @param module 
     * @throws java.io.IOException 
     */
    public void delete (Module module) throws IOException;
    
}
