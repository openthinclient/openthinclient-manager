/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.autoupdate;

import java.awt.Image;
import java.beans.*;

import org.openide.util.NbBundle;

/** BeanInfo for Autoupdate settings
*
* @author Ales Kemr
*/
public class XMLAutoupdateTypeBeanInfo extends SimpleBeanInfo {
    
    /**
    * loads icons
    */
    public XMLAutoupdateTypeBeanInfo() {
    }

    /** Returns the ExternalCompilerSettings' icon */
    public Image getIcon(int type) {
        if ((type == java.beans.BeanInfo.ICON_COLOR_16x16) || (type == java.beans.BeanInfo.ICON_MONO_16x16)) {
            return org.openide.util.Utilities.loadImage("org/netbeans/modules/autoupdate/resources/updateAction.gif"); // NOI18N
        } else {
            return org.openide.util.Utilities.loadImage("org/netbeans/modules/autoupdate/resources/updateAction32.gif"); // NOI18N
        }
    }
    
    public BeanInfo[] getAdditionalBeanInfo () {
        try {
            return new BeanInfo[] { Introspector.getBeanInfo (AutoupdateType.class) };
        } catch (IntrospectionException ie) {
            org.openide.ErrorManager.getDefault().notify(ie);
            return null;
        }
    }

    public BeanDescriptor getBeanDescriptor () {
        BeanDescriptor bdesc = new BeanDescriptor (XMLAutoupdateType.class);
        
        bdesc.setDisplayName (getBundle("CTL_XMLAutoupdateType_Name"));
        bdesc.setValue ("version", "1.1"); // NOI18N
        return bdesc;
    }

    /** Descriptor of valid properties
    * @return array of properties
    */
    public PropertyDescriptor[] getPropertyDescriptors () {
        PropertyDescriptor[] desc = null;
    
        try {
            desc = new PropertyDescriptor[] {
                       new PropertyDescriptor("URL", XMLAutoupdateType.class),
                       new PropertyDescriptor("enabled", AutoupdateType.class),
                       new PropertyDescriptor("lastTimeStamp", AutoupdateType.class)
                   };

            desc[0].setDisplayName(getBundle("PROP_Url"));
            desc[0].setShortDescription(getBundle("HINT_Url"));            
            
            desc[1].setDisplayName(getBundle("PROP_Enabled"));
            desc[1].setShortDescription(getBundle("HINT_Enabled"));            

            desc[2].setDisplayName(getBundle("PROP_LastTimeStamp"));
            desc[2].setShortDescription(getBundle("HINT_LastTimeStamp"));
            desc[2].setPropertyEditorClass(Settings.LastCheckPropertyEditor.class);
            desc[2].setValue("canEditAsText",Boolean.FALSE);  // NOI18N
            
            
        } catch (IntrospectionException ex) {
            //throw new InternalError ();
            ex.printStackTrace ();
        }
        return desc;
    }
    
    private static String getBundle( String key ) {
        return NbBundle.getMessage( XMLAutoupdateTypeBeanInfo.class, key );
    }
}
