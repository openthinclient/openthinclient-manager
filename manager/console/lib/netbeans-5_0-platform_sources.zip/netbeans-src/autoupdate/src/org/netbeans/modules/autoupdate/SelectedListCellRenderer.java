/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.autoupdate;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.DefaultListCellRenderer;

/** Just sets the right icon to IndexItem

 @author Petr Hrebejk
*/
class SelectedListCellRenderer extends DefaultListCellRenderer {

    static final long serialVersionUID =-4278857657314562123L;
    public Component getListCellRendererComponent( JList list,
            Object value,
            int index,
            boolean isSelected,
            boolean cellHasFocus) {
        JLabel cr = (JLabel)super.getListCellRendererComponent( list, value, index, isSelected, cellHasFocus );

        if ( ((ModuleUpdate)value).isDownloadOK() )
            cr.setIcon( getProperIcon("ok") );
        else if ( ((ModuleUpdate)value).isPurchased() )
            cr.setIcon( getProperIcon("purchasedModule") );
        else if ( value instanceof L10NUpdate )
            cr.setIcon( getProperIcon("localeModule") );
        else
            cr.setIcon( ((ModuleUpdate)value).isNew() ? getProperIcon("newModule") : getProperIcon("updateModule") );
        cr.setText( ((ModuleUpdate)value).getName() );        
 
        return cr;
    }
    
    private ImageIcon getProperIcon(String type) {
        return new ImageIcon ( org.openide.util.Utilities.loadImage(
            "org/netbeans/modules/autoupdate/resources/" + type + ".gif" // NOI18N
            )
        );
    }
}
