/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2005 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.autoupdate;

import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import org.openide.awt.StatusLineElementProvider;
import org.openide.util.Utilities;

/**
 *
 * @author  Jiri Rechtacek
 */
public final class AvailableUpdateVisualizerProvider implements StatusLineElementProvider {

    public Component getStatusLineElement () {
        return getUpdatesVisualizer ();
    }

    private static UpdatesFlasher flasher = null;
    
    private static Runnable onMouseClick = null;

    /**
     * Return an icon that is flashing when a new internal exception occurs. 
     * Clicking the icon opens the regular exception dialog box. The icon
     * disappears (is hidden) after a short period of time and the exception
     * list is cleared.
     *
     * @return A flashing icon component or null if console logging is switched on.
     */
    private static Component getUpdatesVisualizer () {
        if (null == flasher) {
            ImageIcon img1 = new ImageIcon (Utilities.loadImage ("org/netbeans/modules/autoupdate/resources/newUpdates.gif", false));
            assert img1 != null : "Icon cannot be null.";
            flasher = new UpdatesFlasher (img1);
        }
        return flasher;
    }
    
    static UpdatesFlasher getFlasher (Runnable whatRunOnMouseClick) {
        onMouseClick = whatRunOnMouseClick;
        return flasher;
    }
    
    static class UpdatesFlasher extends FlashingIcon {
        public UpdatesFlasher (Icon img1) {
            super (img1);
            DISAPPEAR_DELAY_MILLIS = -1;
            // don't flashing by http://ui.netbeans.org/docs/ui/AutoUpdate/AutoUpdate.html
            STOP_FLASHING_DELAY = 0;
        }

        /**
         * User clicked the flashing icon, display the exception window.
         */
        protected void onMouseClick () {
            if (onMouseClick != null) {
                onMouseClick.run ();
                disappear ();
            }
        }
        
        /**
         * The flashing icon disappeared (timed-out), clear the current
         * exception list.
         */
        protected void timeout () {}
    }
    
}
