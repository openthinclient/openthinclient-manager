/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2001 Sun
 * Microsystems, Inc. All Rights Reserved.
 */
package org.netbeans.modules.autoupdate;

import org.openide.loaders.*;
import org.openide.nodes.*;
import org.openide.util.NbBundle;

/** A node to represent this object.
 *
 * @author Ales Kemr
 */
class NbmDataNode extends DataNode {

    public NbmDataNode (NbmDataObject obj) {
        this (obj, Children.LEAF);
    }

    public NbmDataNode (NbmDataObject obj, Children ch) {
        super (obj, ch);
        setIconBase ("org/netbeans/modules/autoupdate/resources/updateModule");
        setShortDescription (NbBundle.getMessage (NbmDataNode.class, "HINT_NbmDataNode"));
    }

    protected NbmDataObject getNbmDataObject () {
        return (NbmDataObject) getDataObject ();
    }

}
