/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2003 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.api.registry.fs;

import org.netbeans.core.registry.ContextImpl;
import org.netbeans.core.registry.ResettableContextImpl;
import org.netbeans.spi.registry.BasicContext;
import org.openide.ErrorManager;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.FileStateInvalidException;
import org.openide.filesystems.Repository;

/** 
 * This class contains helper methods for creation of BasicContext over the
 * Filesystem. 
 *
 * @author  David Konecny
 */
public final class FileSystemContextFactory {

    private FileSystemContextFactory() {
    }
    
    /** 
     * Create context implementation over the Filesystem. The
     * passed file object will be root of the context hierarchy.
     *
     * @param root file object which will be root of the context hierarchy
     * @return instance of RootContext created for the given fileobject
     * @deprecated relation between FileObjects and Contexts is just implementation detail.
     * No replacement for this method. 
     */    
    public static BasicContext createContext(FileObject root) {
        BasicContext rc;
        boolean isSFS = false;
        try {
            isSFS = root.getFileSystem().equals(Repository.getDefault().getDefaultFileSystem());
        } catch (FileStateInvalidException ex) {
            ErrorManager.getDefault().log(ErrorManager.WARNING, ex.toString());
            isSFS = false;
        }
        if (isSFS) {
            rc = new ResettableContextImpl(root);
        } else {
            rc = new ContextImpl (root);
        }
        return rc;
    }
    
}
