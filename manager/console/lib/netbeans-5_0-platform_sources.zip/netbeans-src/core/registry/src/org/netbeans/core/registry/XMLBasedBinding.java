/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2003 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.core.registry;

import org.openide.filesystems.FileObject;
import org.openide.loaders.DataObject;
import org.openide.loaders.DataObjectNotFoundException;
import org.openide.cookies.InstanceCookie;
import org.netbeans.spi.registry.BasicContext;

import java.io.IOException;

/**
 * Provides ObjectBinding.Reader for ObjectBinding implementation.
 * 
 * Backward compatibility for XML based instances. Impl. based on 
 * datasystems.  
 */

final class XMLBasedBinding extends ObjectBinding.Reader {
    static final ObjectBinding.Reader READER = new XMLBasedBinding ();
    
    private XMLBasedBinding () {}
    
    boolean canRead(FileObject fo) {
        boolean retVal = (fo.getExt().equals(getFileExtension()));

        if (retVal) {
            try {
                InstanceCookie ic = getInstanceCookie(fo);
                retVal = (ic != null);
            } catch (DataObjectNotFoundException e) {
                retVal = false;
            }
        }
        return retVal;
    }

    private static InstanceCookie getInstanceCookie(FileObject fo) throws DataObjectNotFoundException {
        DataObject d = DataObject.find(fo);
        return (InstanceCookie)d.getCookie(InstanceCookie.class);
    }

    String getFileExtension() {
        return "xml";//NOI18N
    }

    ObjectBinding getObjectBinding(BasicContext ctx, FileObject fo) {
        return new ObjectBindingImpl (fo);
    }
    
    private class ObjectBindingImpl extends ObjectBinding {
        InstanceCookie ic;
        ObjectBindingImpl(FileObject fo) {
            super(fo);
        }

        public Object createInstance() throws IOException {
            InstanceCookie icLocal = (ic != null) ? ic : getInstanceCookie(getFile());
            try {
                return icLocal.instanceCreate();
            } catch (ClassNotFoundException e) {
                throw new IOException(e.getLocalizedMessage());   
            }
        }

        public boolean isEnabled() {            
            return (getFile() != null && getFile().isValid());
        }
    }
}
