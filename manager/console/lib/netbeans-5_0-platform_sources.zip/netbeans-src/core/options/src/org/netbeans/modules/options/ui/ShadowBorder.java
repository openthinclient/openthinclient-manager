/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is NetBeans. The Initial Developer of the Original
 * Code is Sun Microsystems, Inc. Portions Copyright 1997-2000 Sun
 * Microsystems, Inc. All Rights Reserved.
 */

package org.netbeans.modules.options.ui;


import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.SystemColor;
import javax.swing.border.Border;


/**
 *
 * @author Jan Jancura
 */
public class ShadowBorder implements Border {
    
    private Insets insets = new Insets (1, 1, 3, 3);
    
    
    public void paintBorder (
        Component c, 
        Graphics g, 
        int x, int y, int width, int height
    ) {
        g.setColor (SystemColor.controlDkShadow); //Color.gray);
        g.drawRect (x, y, width - 3, height - 3);
        g.setColor (SystemColor.controlShadow); //Color.lightGray);
        g.drawLine (x + 2, height - 2, width - 1, height - 2);
        g.drawLine (x + 2, height - 1, width - 1, height - 1);
        g.drawLine (width - 2, y + 2, width - 2, height - 1);
        g.drawLine (width - 1, y + 2, width - 1, height - 1);
        g.setColor (SystemColor.control);
        g.drawRect (x, height - 2, 1, 1);
        g.drawRect (width - 2, y, 1, 1);
    }

    public Insets getBorderInsets (Component c) {
        return insets;
    }

    public boolean isBorderOpaque () {
        return true;
    }
}
